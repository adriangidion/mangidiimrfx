
export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold">Welcome to MangidiimrFX</h1>
      <p className="text-md mt-2">The Champion Goat of Trading 🐐📈</p>
      <div className="mt-6 space-x-4">
        <a href="/login" className="px-4 py-2 bg-blue-500 text-white rounded">Login</a>
        <a href="/register" className="px-4 py-2 bg-green-500 text-white rounded">Register</a>
      </div>
    </div>
  );
}
