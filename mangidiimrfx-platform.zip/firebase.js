
import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyCS__-FQhevTbhNRDQrmEdoEDyI0h6vdqk",
  authDomain: "mangidiimrfx-platform.firebaseapp.com",
  projectId: "mangidiimrfx-platform",
  storageBucket: "mangidiimrfx-platform.firebasestorage.app",
  messagingSenderId: "323528372327",
  appId: "1:323528372327:web:5ebfebe1592aabd828a4c2"
};

const app = initializeApp(firebaseConfig);
export default app;
